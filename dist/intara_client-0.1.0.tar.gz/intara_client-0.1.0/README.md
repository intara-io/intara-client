# Intara Python Client

## Table of Contents

- [Installation](#installation)
- [Getting Started](#getting-started)
- [Usage](#usage)
  - [SERP Data Retrieval](#serp-data-retrieval)
  - [Monthly Search Volume (MSV)](#monthly-search-volume-msv)
  - [Alpha Parser](#alpha-parser)
- [Location Codes](#location-codes)
- [Notes](#notes)
- [License](#license)

## Installation

To use the Intara Python Client, you need to have Python 3.7 or later installed. You can install the client by cloning the repository and installing the required packages.

```bash
git clone https://github.com/yourusername/intara-python-client.git
cd intara-python-client
pip install -r requirements.txt
```

Alternatively, if the package is available on PyPI:

```bash
pip install intara-client
```

## Getting Started

First, you need to obtain an API key from Intara. Replace `"YOUR_API_KEY"` with your actual API key in the examples below.

## Usage

### Importing and Initializing the Client

```python
from intara_client.client import IntaraClient

client = IntaraClient(api_key="YOUR_API_KEY")
```

### SERP Data Retrieval

Retrieve SERP data for a given keyword.

```python
# Single keyword
serp_data = client.serp("pizza")
print(serp_data[0])

# Multiple keywords
serp_data = client.serp(["pizza", "burger"])
for data in serp_data:
    print(data)
```

**Example Output:**

```json
{
  'id': 'a9ed4c2f-0b7b-4aa8-b017-0140e28c1476',
  'fetched_at': '2024-09-13T20:02:19.963084Z',
  'type': 'organic',
  'rank_group': 1,
  'rank_absolute': 1,
  'position': 'left',
  'title': 'Pizza Hut | Delivery & Carryout - No One OutPizzas The Hut!',
  'domain': 'www.pizzahut.com',
  'url': 'https://www.pizzahut.com/',
  'description': 'Discover classic & new menu items, find deals and enjoy seamless ordering for delivery and carryout. No One OutPizzas the Hut®.',
  'is_paid': False,
  'rating_value': None,
  'rating_votes_count': None,
  'rating_max': None,
  'keyword_serp': '75301203-ee30-4a8e-b27c-9564d8ee4c58'
}
```

#### Using `location_code`

You can specify a `location_code` to get location-specific SERP data.

```python
# Using a specific location code (e.g., New York State)
serp_data = client.serp("pizza", location_code=21167)
print(serp_data[0])
```

**Example Output:**

```json
{
  'id': '8302e991-d44e-45f6-b7cb-072c4140bfe0',
  'fetched_at': '2024-09-14T11:02:41.100561Z',
  'type': 'local_pack',
  'rank_group': 1,
  'rank_absolute': 1,
  'position': 'left',
  'title': "Franco's Pizzeria and Deli",
  'domain': None,
  'url': None,
  'description': 'Syracuse, NY \nLate-night Italian & American eatery \n',
  'is_paid': False,
  'rating_value': 3.8,
  'rating_votes_count': 958,
  'rating_max': 5.0,
  'keyword_serp': 'f27a15c7-4838-47da-b857-92c893b2a860'
}
```

### Monthly Search Volume (MSV)

Retrieve MSV data for a given keyword.

```python
# Single keyword
msv_data = client.msv("pizza")
print(msv_data)

# Multiple keywords
msv_data = client.msv(["pizza", "burger"])
for data in msv_data:
    print(data)
```

**Example Output:**

```json
{
  'id': 'e5620899-8917-4f04-bb01-dbc9cb634e0c',
  'keyword': 'pizza',
  'location_code': 2840,
  'language_code': 'en',
  'search_partners': False,
  'competition': 'LOW',
  'competition_index': 7,
  'search_volume': 7480000,
  'low_top_of_page_bid': 1.41,
  'high_top_of_page_bid': 2.87,
  'cpc': 2.61,
  'last_updated': '2024-09-13T20:02:42.885518Z'
}
```

#### Using `location_code`

```python
# Using a specific location code (e.g., New York State)
msv_data = client.msv("pizza", location_code=21167)
print(msv_data)
```

**Example Output:**

```json
{
  'id': 'a5f48e62-d3b7-49cc-bd05-f73ad869078c',
  'keyword': 'pizza',
  'location_code': 21167,
  'language_code': 'en',
  'search_partners': False,
  'competition': 'LOW',
  'competition_index': 7,
  'search_volume': 7480000,
  'low_top_of_page_bid': 1.41,
  'high_top_of_page_bid': 2.87,
  'cpc': 2.61,
  'last_updated': '2024-09-14T11:04:37.793329Z'
}
```

### Alpha Parser

Parse a webpage to extract structured data using the Alpha Parser.

```python
parsed_data = client.alpha_parser(
    url="https://www.zocdoc.com/acupuncturists/dallas-211240pm",
    industry="Healthcare"
)
print(parsed_data)
```

**Important:** The `industry` argument is case-sensitive.

#### Refreshing Cache

By default, the Alpha Parser may return cached results. To force a fresh analysis, set `disable_cache` to `True`.

```python
parsed_data = client.alpha_parser(
    url="https://www.zocdoc.com/acupuncturists/dallas-211240pm",
    industry="Healthcare",
    disable_cache=True
)
```

## Location Codes

The `location_code` parameter is used to specify the geographical location for SERP and MSV data. You can find the appropriate `location_code` from the `locations_us.csv` or `locations_all.csv` files.

**Example Entry from `locations_us.csv`:**

```csv
location_code,location_name,location_code_parent,country_iso_code,location_type
21167,"New York,United States",2840.0,US,State
```

In this example, the `location_code` for New York State is `21167`.

## Notes

- The `industry` argument in the `alpha_parser` method is **case-sensitive**.
- Set `disable_cache` to `True` in the `alpha_parser` method to force a fresh analysis of the webpage.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.